//
// Get elements from Connector has conveyed Elements
//
select  o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE, o.name As Element
from t_object o,

where  o.element_id in ( #CONVEYED_ITEM_IDS# )
ORDER BY 3
