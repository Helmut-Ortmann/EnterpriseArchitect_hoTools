//
// Template DiagramElements_IDS
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type 
from t_object o
where o.object_ID in (#DiagramElements_IDS#)
  
ORDER BY o.Name
              