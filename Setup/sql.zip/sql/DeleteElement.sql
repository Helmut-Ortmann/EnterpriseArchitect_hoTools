//
// Template delete current Element 
//
delete from t_object 
where object_ID = #CurrentItemID#
