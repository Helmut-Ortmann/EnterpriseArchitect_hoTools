//
// Template delete tree selected 
//
delete from t_object 
where ea_guid in (#TreeSelectedGUIDS#)
