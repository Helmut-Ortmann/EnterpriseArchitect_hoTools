//
// Script t_script
// ScriptID         ID, auto generated)
// ScriptCategory   Group:  "3955A83E-9E54-4810-8053-FACC68CD4782"
//                  Script: "605A62F7-BCD0-4845-A8D0-7DC45B4D2E3F"
// ScriptAuthor     Group:  GUID as identification of Group
//                  Script: GUID as Group the script belongs to (JOIN script with GROUP)
// Notes:           <Script Name =".." Type="Internal" Language="VBScript"/>
//                  <Group Type="Normal" Notes=""/>
// Script:          The Script itself
//                  The Group Name
//
select * from t_script
         where ScriptCategory in ("3955A83E-9E54-4810-8053-FACC68CD4782",
                                  "605A62F7-BCD0-4845-A8D0-7DC45B4D2E3F")
