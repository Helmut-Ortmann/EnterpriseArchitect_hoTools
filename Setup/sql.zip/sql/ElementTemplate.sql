//
// Template Element
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, * 
from t_object o
where o.name like '<Search Term>#WC#' AND      o.object_type in 
     (
      "Class","Component"
      )
ORDER BY o.Name