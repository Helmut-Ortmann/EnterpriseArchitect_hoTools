//
// Template #Branch={...guid...}#
// Get Package recursive for package according to GUID
//
select pkg.ea_guid AS CLASSGUID, 'Package' AS CLASSTYPE,pkg.Name AS Name,'Package' As Type 
from t_package pkg
where pkg.package_ID in (#Branch={0E702249-BFFA-43cd-86C9-41D3324A7617}#)
     
ORDER BY pkg.Name