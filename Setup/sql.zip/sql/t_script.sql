//
// Get Script for name
//
select * 
from t_script

where Notes like '*"hoDemo2Par"*'