//
// Find Conveyed Element in diagram
// Select Element and get diagram
//
select  s.ea_guid AS CLASSGUID, s.object_type AS CLASSTYPE, s.name As Source , d.name As Destination
from t_xref x,   // a lot of things like properties,..
     t_connector c,
     t_object s, // Souce element
     t_object d  // destination element

where  x.description like  '#WC##CurrentElementGUID##WC#' AND
       x.Behavior = 'conveyed' AND
       c.ea_guid = x.client

and    c.ea_guid = x.client
and    c.start_object_id = s.object_id
and    c.end_object_id = d.object_id
ssf
dd
