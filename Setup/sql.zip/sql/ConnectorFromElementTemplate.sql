//
// Connector from selected Element
// Gets the connectors which has the selected Element as Conveyed Item
//
//Sample Script to show:     
//- How to find connectors which conveye elements
//- <Search Term>: GUID of the element to search the connectors
//
// Results:
// - Source Element to jump to diagrams (Port, Element)
// - Target Element of the connector (Port, Element)
// - Diagram it is shown in
// - etc.
// - You can right click on the source to find the diagrams that may contain the connector_type/

// Find Ports as source and destination of connector
SELECT DISTINCT s.ea_guid as CLASSGUID, s.Object_Type as CLASSTYPE, 'Source' As [Direction], pkg.Name As Package,
dia.Name as Diagramm,   s1.name As 'Class 1', s.name As 'Port 1',o.name As Signal, d1.name As 'Class 2', d.name As 'Port 2',
c.connector_type As 'Connector Type', link.Hidden, c.name As 'Connector Name', c.stereotype As 'Connector Stereotype'
FROM t_object o,
          t_xref x,   // here are the references from connector to conveyed elements
          t_connector c,
          t_object s, // Sourece of connector (Port)
          t_object d, // Destination of connector (Port)
		      t_object s1,
          t_object d1,
          t_diagramlinks link,
          t_diagram  dia,
		  t_package pkg
where o.ea_guid= '<Search Term>'
and    x.description like  '#WC#<Search Term>#WC#'
and s.parentid = s1.object_ID
and d.parentid = d1.object_ID

and    c.ea_guid = x.client
and    c.start_object_id = s.object_id
and    c.end_object_id = d.object_id
and    link.ConnectorID = c.Connector_Id
and    link.DiagramID = dia.Diagram_ID
and    pkg.Package_Id = dia.Package_Id
and x.Behavior = 'conveyed'

and  exists (select * from t_diagramobjects y where (c.start_object_id = y.Object_Id)   and Diagram_ID = dia.Diagram_Id)
and  exists (select * from t_diagramobjects y where (c.end_object_id = y.Object_Id)   and Diagram_ID = dia.Diagram_Id)

UNION
// Find Elements source and destination of connector
SELECT DISTINCT d.ea_guid , d.Object_Type , 'Target', pkg.Name As Package,
dia.Name as Diagramm,   s1.name ,  s.name ,o.name As Signal, d1.name , d.name ,
c.connector_type , link.Hidden, c.name , c.stereotype
FROM t_object o,
          t_xref x,     // here are the references from connector to conveyed elements
          t_connector c,
          t_object s,
		      t_object s1,
          t_object d,
		      t_object d1,
          t_diagramlinks link,
          t_diagram  dia,
		      t_package pkg
where o.ea_guid= '<Search Term>'
and    x.description like  '#WC#<Search Term>#WC#'
and s.parentid = s1.object_ID
and d.parentid = d1.object_ID

and    c.ea_guid = x.client
and    c.start_object_id = s.object_id
and    c.end_object_id = d.object_id
and    link.ConnectorID = c.Connector_Id
and    link.DiagramID = dia.Diagram_ID
and    pkg.Package_Id = dia.Package_Id
and x.Behavior = 'conveyed'

and  exists (select * from t_diagramobjects y where (c.start_object_id = y.Object_Id)   and Diagram_ID = dia.Diagram_Id)
and  exists (select * from t_diagramobjects y where (c.end_object_id = y.Object_Id)   and Diagram_ID = dia.Diagram_Id)


order by 5,6,7,3
