//
// Update Script
//
update t_script set Script = "dummy"
where ScriptID = 305
