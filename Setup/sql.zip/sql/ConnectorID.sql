//
// Template ConnectorID
//

//
// Get Elements from selected Connector (conveyed Items)
//
select  c.ea_guid AS CLASSGUID, Connector_Type As CLASSTYPE, *
from t_connector c

where  c.connector_ID = #ConnectorID#