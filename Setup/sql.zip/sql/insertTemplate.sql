//
// Template Insert Element in current selected Package
//
insert into t_object 
   (ea_guid, object_type, Name, Package_ID)
values
   ('#NewGuid#', 'Class', 'XXXX', #Package#)
