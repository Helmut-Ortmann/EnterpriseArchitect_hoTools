//
// Test DB specifics
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, *
from t_object o
where o.name like '<Search Term>#WC#' AND      o.object_type in
     (
#DB_JET#         "Class","Component"                 #DB_JET#
#DB_ASA#          bullshit                   #DB_ASA#
#DB_ACCESS2007#   bullshit                  #DB_ACCESS2007#
#DB_FIREBIRD#     bullshit        #DB_FIREBIRD#
#DB_MYSQL#        bullshit                     #DB_MYSQL#
#DB_ORACLE#       bullshit                      #DB_ORACLE#
#DB_POSTGRES#     bullshit                        #DB_POSTGRES#
#DB_SQLSVR#       bullshit                      #DB_SQLSVR#
      )
ORDER BY o.Name
