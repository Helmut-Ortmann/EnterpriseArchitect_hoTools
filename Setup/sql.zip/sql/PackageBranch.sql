select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, * 
from t_object o, t_package pkg 
where o.object_type = 'Package' AND 
      o.ea_guid = pkg.ea_guid AND
     pkg.Package_id in (#Branch#)