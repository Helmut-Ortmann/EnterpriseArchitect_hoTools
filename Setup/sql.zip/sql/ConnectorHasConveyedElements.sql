//
// Get Elements from selecrted Connector1111
//
select  o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE, o.name As Element
from t_object o

where  o.Object_ID in ( #ConveyedItemIDS# )
