//
// Get current Item ID (Package, Diagram, Element, Attribut, Operation)
//
// Template for macro: #CurrentItemID# or Alias #CurrentElementID#
// Pay Attention: ID may be ambiguous. Better use #CurrentItemId#
//
// V1.00 17. May 2016 created
//

// As Element
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type 
from t_object o
where o.object_ID = #CurrentElementID#

UNION

// As Diagram
select dia.ea_guid AS CLASSGUID, dia.diagram_type AS CLASSTYPE,dia.Name AS Name,dia.diagram_type As Type 
from t_diagram dia
where dia.diagram_ID = #CurrentElementID#

UNION

// As Package
select pkg.ea_guid AS CLASSGUID, 'Package' AS CLASSTYPE,pkg.Name AS Name,'Package' As Type 
from t_package pkg
where pkg.package_ID = #CurrentElementID#



UNION
// As Attribute
select attr.ea_guid AS CLASSGUID,'Attribute',attr.Name AS Name,'Attribute' 
from t_attribute attr
where attr.object_ID = #CurrentElementID#

UNION

// As operation
select opr.ea_guid AS CLASSGUID,'P',opr.Name AS Name,'Operation' 
from t_operation opr
where opr.object_ID = #CurrentElementID#


  



ORDER BY Name
