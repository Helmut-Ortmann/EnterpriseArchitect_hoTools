//
// Test Case and the Element the Test Case is associated to
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE, 
o.name as [Element],
t.Test,
t.Status,
t.TestType

FROM t_objecttests t, t_object o

WHERE 
t.Object_ID = o.Object_ID   


Order by o.name