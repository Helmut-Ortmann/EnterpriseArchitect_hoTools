//
// GetTreeSelectedElements Template
// Get Elements from selected Elements in Browser
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, * 
from t_object o
where o.ea_guid in (#TREE_SELECTED_GUIDS#) 

ORDER BY o.Name
