//
// Template #Branch#
// Select Package and get Packages recursive
//
select pkg.ea_guid AS CLASSGUID, 'Package' AS CLASSTYPE,pkg.Name AS Name,'Package' As Type 
from t_package pkg
where pkg.package_ID = #Package#
     
ORDER BY pkg.Name

