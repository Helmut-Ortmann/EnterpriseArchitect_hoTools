//
// EA-Matic Scripts
//
select s.ScriptID, grp.Script as SCRIPTGROUP, s.ScriptCategory, s.ScriptAuthor, s.Notes, s.Script,  grp.Notes as GROUPNOTES from t_script s
  inner join t_script grp on s.ScriptAuthor = grp.ScriptName
  where s.Script like '%EA-Matic%' AND
        s.Notes like '<Script Name="<Search Term>*"*'
