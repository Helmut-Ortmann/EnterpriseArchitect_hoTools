//
// Output TestCases which starts which a name. If you don't input a search string all Test Cases are output.
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, * 
from t_object o
where o.name like '<Search Term>#WC#' AND
      o.Stereotype = "testcase" AND
      o.object_type in 
     (
      "UseCase"
      )
      
ORDER BY o.Name