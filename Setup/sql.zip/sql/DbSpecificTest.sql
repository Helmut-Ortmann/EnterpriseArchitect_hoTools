//
// Test DB specifics
//
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type, * 
from t_object o
where o.name like '<Search Term>#WC#' AND      o.object_type in 
     (
#DB=JET#         "Class","Component"                 #DB=JET#  
#DB=ASA#          bullshit                   #DB=ASA#  
#DB=ACCESS2007#   bullshit                  #DB=ACCESS2007#
#DB=FIREBIRD#     bullshit        #DB=FIREBIRD#
#DB=MYSQL#        bullshit                     #DB=MYSQL#
#DB=ORACLE#       bullshit                      #DB=ORACLE#
#DB=POSTGRES#     bullshit                        #DB=POSTGRES#
#DB=SQLSVR#       bullshit                      #DB=SQLSVR#
      )
ORDER BY o.Name
