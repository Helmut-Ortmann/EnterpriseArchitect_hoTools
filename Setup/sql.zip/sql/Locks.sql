//
// Template Element
//
select *from t_seclocks