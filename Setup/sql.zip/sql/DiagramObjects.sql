//
// Show Diagram Items
//
select *
from t_diagramobjects do
where do.diagram_id = #Diagram_ID#
