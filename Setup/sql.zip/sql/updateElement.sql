//
// Template Update current Element 
//
update t_object set
   name = 'XXXClass55'
where object_ID = #CurrentItemID#
