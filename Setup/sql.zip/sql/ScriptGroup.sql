//
// Script Group
//
select s.[ScriptID], s.ScriptCategory,s.ScriptAuthor, s.[ScriptName] AS GroupGUID, s.[Notes], s.[Script] as GroupName 
from t_script s 
where s.Notes like '<Group Type=%'
