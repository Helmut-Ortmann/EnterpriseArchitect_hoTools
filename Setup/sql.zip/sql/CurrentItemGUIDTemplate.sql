//
// Get current Item GUID (Package, Diagram, Element, Attribut, Operation)
//
// Template for macro: #CurrentItemGUID# or Alias #CurrentElementGUID#
//
// V1.00 17. May 2016 created
//

// As Element
select o.ea_guid AS CLASSGUID, o.object_type AS CLASSTYPE,o.Name AS Name,o.object_type As Type 
from t_object o
where o.ea_guid = #CurrentElementGUID#

UNION

// As Diagram
select dia.ea_guid AS CLASSGUID, dia.diagram_type AS CLASSTYPE,dia.Name AS Name,dia.diagram_type As Type 
from t_diagram dia
where dia.ea_guid = #CurrentElementGUID#

UNION

// As Package
select pkg.ea_guid AS CLASSGUID, 'Package' AS CLASSTYPE,pkg.Name AS Name,'Package' As Type 
from t_package pkg
where pkg.ea_guid = #CurrentElementGUID#



UNION
// As Attribute
select attr.ea_guid AS CLASSGUID,'Attribute',attr.Name AS Name,'Attribute' 
from t_attribute attr
where attr.ea_guid = #CurrentElementGUID#

UNION

// As operation
select opr.ea_guid AS CLASSGUID,'P',opr.Name AS Name,'Operation' 
from t_operation opr
where opr.ea_guid = #CurrentElementGUID#


  



ORDER BY Name
